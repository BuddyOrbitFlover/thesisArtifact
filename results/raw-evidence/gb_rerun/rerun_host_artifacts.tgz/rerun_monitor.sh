#!/bin/bash
# gb re-run 30-min ntfy monitor (2026-07-14). Auto-stops when stage5 completes.
exec 8>/localhome/klee/rerun_monitor.lock
flock -n 8 || exit 1
NTFY=klee-tbar-9x42qz
while true; do
  EXP=$(podman exec gb-div bash -lc 'n=0; while read b; do [ "$(ls /catena/scripts/construct_database/d4j_export/$b 2>/dev/null | wc -l)" -ge 11 ] && n=$((n+1)); done < /catena/scripts/construct_database/rerun47; echo $n' 2>/dev/null)
  EXC=$(podman exec gb-div bash -lc 'ls /catena/scripts/construct_database/exception_* 2>/dev/null | wc -l' 2>/dev/null)
  MH="-"; S5="-"
  podman exec gb-div test -f /catena/rerun_multihunk.txt 2>/dev/null && {
    MH=$(podman exec gb-div bash -lc 'wc -l < /catena/rerun_multihunk.txt')
    S5=$(podman exec gb-div bash -lc 'n=0; while read b; do [ -f /catena/scripts/generate_bugs/working/$b/newBugs.json ] && n=$((n+1)); done < /catena/rerun_multihunk.txt; echo $n')
  }
  CORES=$(podman exec gb-div bash -lc 'ps -eo pcpu,comm | grep -E "[j]ava|[p]ython" | awk "{s+=\$1} END {printf \"%.0f\", s/100}"' 2>/dev/null)
  D1="-"; podman exec gb-div test -f /catena/stage1.done 2>/dev/null && D1=done
  MSG="gb-rerun: stage1=$D1 exports=$EXP/47 checkout_exc=$EXC | multihunk=$MH stage5_analyzed=$S5 | ~${CORES:-0} cores"
  if podman exec gb-div test -f /catena/rerun_stage5.done 2>/dev/null; then
    curl -s -d "$MSG — STAGE 5 COMPLETE, monitor stopping" ntfy.sh/$NTFY >/dev/null
    exit 0
  fi
  curl -s -d "$MSG" ntfy.sh/$NTFY >/dev/null
  sleep 1800
done
