#!/bin/bash
exec 9>/catena/stage5.lock
flock -n 9 || { echo "stage5 already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
cd /catena/scripts/generate_bugs
cp -n 2toMore 2toMore.pilot14.bak
cp /catena/rerun_multihunk.txt 2toMore
cp /catena/rerun_res5.json ./rerun_res5.json
echo "=== STAGE 5 (IBugFinder) start $(date) — 31 bugs, -n 4, paper caps ==="
python3 run.py -m ../construct_database/d4j_export/database.rerun47.json -t ./rerun_res5.json -p ../parse_patches/patches -n 4
echo "=== run.py exited rc=$? $(date) ==="
echo "=== VERDICT ==="
python3 verdict.py
touch /catena/rerun_stage5.done
