#!/bin/bash
exec 9>/catena/stage4.lock
flock -n 9 || { echo "stage4 already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
cd /catena/scripts/split_tests
mkdir -p running running_pilot_bak
mv running/* running_pilot_bak/ 2>/dev/null
python3 run.py ./tableGB -d /gb -f /catena/rerun_multihunk.txt -w /tmp/rerun -m /catena/scripts/construct_database/d4j_export/database.rerun47.json 2>&1 | tail -5
cp running/res5.json /catena/rerun_res5.json
python3 - <<'PY'
import json
res = json.load(open('/catena/rerun_res5.json'))
mh = [l.strip() for l in open('/catena/rerun_multihunk.txt') if l.strip()]
missing = [b for b in mh if b not in res]
print('STAGE4 DONE: {} bugs in rerun_res5.json (expect 31)'.format(len(res)))
print('missing vs multihunk list:', missing if missing else 'NONE')
PY
