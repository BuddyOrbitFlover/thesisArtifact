#!/bin/bash
exec 9>/catena/stage2.lock
flock -n 9 || { echo "stage2 already running"; exit 1; }
cd /catena/scripts/parse_patches
for P in IO Validator Pool Tika_core Wicket_core Johnzon_core Shiro_core Rdf4j_rio_turtle AaltoXml Woodstox Jcabi_http Jcabi_log Dagger_core Google_java_format_core Zip4j Spoon Javapoet Markedj Tape RTree Proj4J Streamex Vectorz Disklrucache; do
  python3 parse_defects4j_v2_0.py /gb $P >/dev/null 2>&1 || echo "PARSE FAIL $P"
done
python3 - <<'PY'
import json, os
bugs = [l.strip().replace(' ', '_') for l in open('/catena/rerun_bugs_cap2.txt') if l.strip()]
fresh = [b for b in bugs if not b.startswith(('Bcel_', 'Graph_', 'Text_', 'Jimfs_'))]
mh = []
for b in fresh:
    p, bid = b.rsplit('_', 1)
    fp = 'patches/{}/{}.json'.format(p, bid)
    if not os.path.exists(fp):
        print('MISSING PATCH JSON: ' + b); continue
    nh = json.load(open(fp))['num_of_hunks']
    if nh >= 2: mh.append(b)
    print('{}: {} hunks{}'.format(b, nh, '  <-- MULTI' if nh >= 2 else ''))
open('/catena/rerun_multihunk.txt', 'w').write('\n'.join(mh) + '\n')
print('MULTI-HUNK: {}/{}'.format(len(mh), len(fresh)))
PY
