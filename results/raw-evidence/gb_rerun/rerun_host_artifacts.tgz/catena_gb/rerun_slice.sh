#!/bin/bash
exec 9>/catena/slice.lock
flock -n 9 || { echo "another slice instance is running — refusing to start"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
LOG=/catena/rerun_slice.log SUM=/catena/rerun_slice_summary.txt
mkdir -p /catena/slice_done
while read -r p b; do
  [ -e /catena/slice_done/$p ] && { echo "SKIP $p (done)"; continue; }
  w=/tmp/slice_$$_$p; rm -rf $w; T0=$SECONDS
  echo "=====$p $b $(date)=====" >> $LOG
  if ! timeout 900  defects4j checkout -p $p -v ${b}b -w $w >>$LOG 2>&1; then
    echo "$p $b CHECKOUT_FAIL" | tee -a $SUM; rm -rf $w; continue; fi
  if ! timeout 2400 defects4j compile -w $w >>$LOG 2>&1; then
    echo "$p $b COMPILE_FAIL t=$((SECONDS-T0))s" | tee -a $SUM; rm -rf $w; continue; fi
  if ! timeout 4500 defects4j test -w $w >>$LOG 2>&1; then
    echo "$p $b TEST_FAIL_OR_TIMEOUT t=$((SECONDS-T0))s" | tee -a $SUM; rm -rf $w; continue; fi
  ft=$(grep '^---' $w/failing_tests 2>/dev/null | sort)
  tt=$(grep '^---' /gb/framework/projects/$p/trigger_tests/$b 2>/dev/null | sort)
  if [ "$ft" = "$tt" ]; then
    echo "$p $b OK t=$((SECONDS-T0))s triggers_match($(echo "$tt" | grep -c .))" | tee -a $SUM
  else
    echo "$p $b TRIGGER_MISMATCH t=$((SECONDS-T0))s failing=$(echo "$ft" | grep -c .) expected=$(echo "$tt" | grep -c .)" | tee -a $SUM
    { echo "--- $p failing:"; echo "$ft"; echo "--- $p expected:"; echo "$tt"; } >> $LOG
  fi
  touch /catena/slice_done/$p; rm -rf $w
done < /catena/slice_first_bugs.txt
echo "SLICE COMPLETE $(date)" | tee -a $SUM
