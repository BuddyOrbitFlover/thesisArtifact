#!/bin/bash
export PATH=/gb/framework/bin:$PATH
ok=0; fails=()
while read -r p b; do
  w=/tmp/smoke_${p}_${b}; rm -rf "$w"
  if defects4j checkout -p "$p" -v "${b}b" -w "$w" >/dev/null 2>&1; then ok=$((ok+1)); else fails+=("$p $b"); fi
  rm -rf "$w"
done < /catena/rerun_bugs_fresh.txt
echo "SMOKE: OK=$ok FAIL=${#fails[@]} of $(wc -l < /catena/rerun_bugs_fresh.txt)"
[ ${#fails[@]} -gt 0 ] && printf 'FAIL %s\n' "${fails[@]}"
