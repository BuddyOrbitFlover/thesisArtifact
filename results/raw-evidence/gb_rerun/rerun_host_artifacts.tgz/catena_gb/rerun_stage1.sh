#!/bin/bash
exec 9>/catena/stage1.lock
flock -n 9 || { echo "stage1 already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
cd /catena/scripts/construct_database
mkdir -p /tmp/rerun
rm -f exception_*
echo "== checkouts (n_jobs=6) $(date) =="
python3 check_out_projects.py ./rerun47 /tmp/rerun
ls exception_* 2>/dev/null || echo "checkouts clean"
echo "== exports (sequential, resumable) $(date) =="
python3 export_metadata2.py ./rerun47 /tmp/rerun
echo "== convert $(date) =="
cp -n d4j_export/database.json d4j_export/database.json.pilot26.bak
python3 convert_metadata.py ./rerun47 /tmp/rerun /gb
mv d4j_export/database.json d4j_export/database.rerun47.json
cp d4j_export/database.json.pilot26.bak d4j_export/database.json
echo "STAGE1 DONE: $(python3 -c "import json;print(len(json.load(open('d4j_export/database.rerun47.json'))))")/47 in database.rerun47.json $(date)"
touch /catena/stage1.done
