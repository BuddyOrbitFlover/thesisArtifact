#!/bin/bash
# rq2_tbar3.sh - census RQ2 TBar: 4 workers, per-worker tbar copies, RESULTS_GB3
# usage: (default)=launch [prep+4 workers+watchdog] | worker N | watchdog   (internal)
set -u
MODE=${1:-launch}

if [ "$MODE" = worker ]; then
  N=$2
  export PATH=/root/binshim:/gb/framework/bin:/catena:$PATH
  export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
  W=/catena/wkgb_$N
  cd $W || exit 1
  echo "=== WORKER $N START $(date) - $(wc -l < /catena/tbar3_chunk_$N.txt) bugs ==="
  while read BUG; do
    [ -z "$BUG" ] && continue
    [ -e /catena/RESULTS_GB3/done/$BUG ] && { echo "$BUG: done, skip"; continue; }
    if [ ! -s /catena/FL/$BUG/ochiai.ranking.txt ]; then
      echo "$BUG: NO-FL, attrition-skip"; touch /catena/RESULTS_GB3/done/$BUG; continue; fi
    mkdir -p C4J_location/105SampleBugsResult/$BUG
    cp -f /catena/FL/$BUG/ochiai.ranking.txt C4J_location/105SampleBugsResult/$BUG/ochiai.ranking.txt
    export TBAR_EXTRA_CP=$(cat /catena/FL/$BUG/cp.txt)
    echo "--- $BUG start $(date) ---"
    echo $BUG > $W/one_bug.txt
    timeout -k 60 19000 python3 runTBarForCatenaD4J.py 0 0 $W $W/one_bug.txt /gb
    for kind in FixedBugs PartiallyFixedBugs; do
      for d in OUTPUT/NormalFL/TBar/*/$kind/$BUG; do
        [ -d "$d" ] && mkdir -p /catena/RESULTS_GB3/fixed/$BUG && \
          cp -r "$d" /catena/RESULTS_GB3/fixed/$BUG/$(basename $(dirname $(dirname $d)))_$kind
      done
    done
    touch /catena/RESULTS_GB3/done/$BUG
    echo "--- $BUG end $(date) fixed_dirs=$(ls /catena/RESULTS_GB3/fixed/$BUG 2>/dev/null | wc -l) ---"
    pkill -9 -f "/catena/wkgb_$N" 2>/dev/null
    sleep 3
  done < /catena/tbar3_chunk_$N.txt
  echo "=== WORKER $N DONE $(date) ==="
  touch /catena/tbar3_w$N.done
  exit 0
fi

if [ "$MODE" = watchdog ]; then
  while :; do
    all=1; for i in 0 1 2 3; do [ -f /catena/tbar3_w$i.done ] || all=0; done
    [ $all = 1 ] && break
    ps -eo pid,etime,stat,comm | \
      awk '$4=="java" && $3 !~ /Z/ && ($2 ~ /-/ || $2 ~ /^([6-9]|[1-9][0-9]+):[0-9][0-9]:[0-9][0-9]$/) {print $1,$2}' | \
      while read pid et; do
        echo "REAPER kill java $pid etime=$et $(date)" >> /catena/tbar3_reaper.log
        kill -9 $pid 2>/dev/null
      done
    sleep 300
  done
  touch /catena/rq2tbar3.done
  curl -s -d "RQ2-census TBar (RESULTS_GB3) ALL 4 WORKERS DONE" ntfy.sh/klee-tbar-9x42qz >/dev/null 2>&1
  exit 0
fi

# ---- launcher ----
exec 9>/catena/rq2tbar3.lock
flock -n 9 || { echo "rq2_tbar3 already running"; exit 1; }
[ -f /catena/rq2fl3.done ] || { echo "ABORT: FL not finished (rq2fl3.done missing); FL pkills java"; exit 1; }
mkdir -p /catena/RESULTS_GB3/done /catena/RESULTS_GB3/fixed
if [ ! -d /catena/wkgb_0 ]; then
  echo "prep: creating 4 tbar worker copies (tar)..."
  for i in 0 1 2 3; do
    mkdir -p /catena/wkgb_$i
    tar -C /catena/tbar -cf - \
      --exclude=./.git --exclude=./D4J --exclude=./logs --exclude=./Log --exclude=./OUTPUT \
      --exclude=./RESULTS_GB --exclude=./RESULTS_GB2 --exclude=./.temp --exclude=./FailedTestCases \
      --exclude=./SuspiciousCodePositions --exclude=./Results --exclude=./C4J_results \
      --exclude=./__pycache__ --exclude=./patch_review.txt . | tar -C /catena/wkgb_$i -xf -
    mkdir -p /catena/wkgb_$i/Log /catena/wkgb_$i/D4J/projects \
      /catena/wkgb_$i/OUTPUT/NormalFL/TBar /catena/wkgb_$i/FailedTestCases \
      /catena/wkgb_$i/SuspiciousCodePositions
  done
  echo "prep: done, $(du -sh /catena/wkgb_0 | cut -f1) per copy"
fi
for i in 0 1 2 3; do
  [ -f /catena/wkgb_$i/runTBarForCatenaD4J.py ] || { echo "ABORT: worker copy $i incomplete (runTBarForCatenaD4J.py missing)"; exit 1; }
done
echo "copy sanity: all 4 workers have the runner ($(du -sh /catena/wkgb_0 | cut -f1) each)"
python3 - <<'PY'
bugs=[l.strip() for l in open('/catena/rq2c_bugs.txt') if l.strip()]
import os
nofl=[b for b in bugs if not os.path.isfile(f'/catena/FL/{b}/ochiai.ranking.txt')]
groups={}
for b in bugs: groups.setdefault(b.rsplit('_',1)[0],[]).append(b)
chunks=[[] for _ in range(4)]
for parent,bs in sorted(groups.items(),key=lambda kv:-len(kv[1])):
    min(chunks,key=len).extend(bs)
for i,c in enumerate(chunks):
    open(f'/catena/tbar3_chunk_{i}.txt','w').write('\n'.join(c)+'\n')
    print(f'chunk {i}: {len(c)} bugs')
print(f'bugs without FL at launch (will attrition-skip): {len(nofl)} {nofl[:6]}')
PY
rm -f /catena/tbar3_w0.done /catena/tbar3_w1.done /catena/tbar3_w2.done /catena/tbar3_w3.done
for i in 0 1 2 3; do
  setsid bash /catena/rq2_tbar3.sh worker $i > /catena/rq2_tbar3_w$i.log 2>&1 < /dev/null &
done
setsid bash /catena/rq2_tbar3.sh watchdog > /dev/null 2>&1 < /dev/null &
echo "=== RQ2-CENSUS TBAR: 4 workers + watchdog launched $(date) ==="
