#!/bin/bash
exec 9>/catena/tinyb_s5.lock
flock -n 9 || { echo "already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
cd /catena/scripts/generate_bugs
cp -n 2toMore 2toMore.census171.bak
cp /catena/tinyb_mh.txt 2toMore
cp /catena/tinyb_res5.json ./tinyb_res5.json
# reaper: any java older than 1h is hung (test cap is 900s) - kill it so it can't wedge the run
(
  while [ ! -f /catena/tinyb_s5.done ]; do
    ps -eo pid,etime,comm | awk '$3=="java" && ($2 ~ /-/ || $2 ~ /^[0-9]+:[0-9][0-9]:[0-9][0-9]$/) {print $1, $2}' | \
    while read pid et; do
      echo "REAPER killed java $pid etime=$et $(date)" >> /catena/tinyb_reaper.log
      kill -9 "$pid" 2>/dev/null
    done
    sleep 300
  done
) &
REAPER=$!
echo "=== TINY-B STAGE 5 start $(date) - $(wc -l < 2toMore) bugs, -n 8, paper caps, reaper on ==="
python3 run.py -m ../construct_database_tinyb/d4j_export/database.tinyb.json -t ./tinyb_res5.json -p ../parse_patches/patches -n 8
echo "=== run.py rc=$? $(date) ==="
echo "=== VERDICT ==="
python3 verdict.py 2>&1 | tee /catena/tinyb_verdict.txt
touch /catena/tinyb_s5.done
kill $REAPER 2>/dev/null
curl -s -d "TINY-B stage5 (35-bug divisibility) DONE" ntfy.sh/klee-tbar-9x42qz >/dev/null 2>&1
