import json
import os
import sys
ex_bugs = ['Cli_6','Collections_20','Collections_24','Collections_1',
           'Collections_21','Collections_2','Collections_5','Collections_10',
           'Collections_6','Collections_15','Collections_7','Collections_17',
           'Collections_22','Collections_8','Collections_18', 'Collections_19',
           'Collections_4', 'Time_21']
with open(sys.argv[1], 'r') as fh:
    waitlist = fh.read().splitlines()
props = ['classes.modified', 'classes.relevant', 'cp.compile', 'cp.test', 'dir.bin.classes', 'dir.bin.tests', 'dir.src.classes', 'dir.src.tests', 'tests.all', 'tests.relevant', 'tests.trigger']
root = {}
skipped = []
bench = os.path.abspath(sys.argv[2])
if not bench.endswith('/'):
    bench += '/'
d4j = '/root/defects4j'
if len(sys.argv) > 3:
    d4j = os.path.abspath(sys.argv[3])
for i in waitlist:
    i = i.split(':')[0]
    if not i:
        continue
    _bench = bench + i
    if any(bug == i for bug in ex_bugs):
        continue
    entry = {}
    path = './d4j_export/{}/'.format(i)
    ok = True
    reason = ''
    for j in props:
        filepath = path + j
        if not os.path.exists(filepath):
            ok = False; reason = 'missing ' + j; break
        with open(filepath, 'r') as fh:
            lines = fh.read().splitlines()
        if j.startswith('tests') or j.startswith('classes'):
            entry[j] = lines
        else:
            if len(lines) != 1:
                ok = False; reason = '{}={} lines'.format(j, len(lines)); break
            v = lines[0]
            if j.startswith('cp'):
                v = v.replace(d4j, '<PathToD4j>').replace(_bench, '<PathToBuggyDir>')
            entry[j] = v
    if ok:
        root[i] = entry
    else:
        skipped.append('{} ({})'.format(i, reason))
with open('./d4j_export/database.json', 'w') as fh:
    fh.write(json.dumps(root, indent=4))
print('converted={} skipped={}'.format(len(root), len(skipped)))
for s in skipped:
    print('  SKIP', s)
