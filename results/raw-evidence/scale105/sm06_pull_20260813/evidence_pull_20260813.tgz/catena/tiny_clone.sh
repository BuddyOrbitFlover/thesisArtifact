#!/bin/bash
REPOS=/gb/framework/projects
clone() {           # clone <PID> <vcs-name> <giturl>  ->  <PID>/project_repos/<vcs-name>.git
  local P="$1" NAME="$2" URL="$3" d
  d="$REPOS/$P/project_repos"; mkdir -p "$d"
  if [ -d "$d/$NAME.git" ]; then echo "SKIP $P ($NAME.git present)"; return 0; fi
  if git clone --bare "$URL" "$d/$NAME.git" >/dev/null 2>&1
    then echo "OK   $P"; else echo "FAIL $P  $URL"; fi
}
clone Commons_suncalc commons-suncalc https://github.com/shred/commons-suncalc.git
clone Config_magic config-magic https://github.com/brianm/config-magic.git
clone Fluo_api fluo-api https://github.com/apache/fluo.git
clone Github_release_plugin github-release-plugin https://github.com/jutzig/github-release-plugin.git
clone Iciql iciql https://github.com/gitblit/iciql.git
clone JacksonDataformatBinary_avro jackson-dataformats-binary-avro https://github.com/FasterXML/jackson-dataformats-binary.git
clone JacksonDataformatsText_properties jackson-dataformats-text-properties https://github.com/FasterXML/jackson-dataformats-text.git
clone JacksonDatatypeJoda jackson-datatype-joda https://github.com/FasterXML/jackson-datatype-joda.git
clone JavaClassmate java-classmate https://github.com/FasterXML/java-classmate.git
clone Jcabi_matchers jcabi-matchers https://github.com/jcabi/jcabi-matchers.git
clone Jfreechart_fse jfreechart-fse https://github.com/jfree/jfreechart-fse.git
clone Metrics_opentsdb metrics-opentsdb https://github.com/sps/metrics-opentsdb.git
clone N5 n5 https://github.com/saalfeldlab/n5.git
clone Rdf4j_rio_api rdf4j-rio-api https://github.com/eclipse/rdf4j.git
clone Rdf4j_rio_jsonld rdf4j-rio-jsonld https://github.com/eclipse/rdf4j.git
clone Rdf4j_rio_rdfjson rdf4j-rio-rdfjson https://github.com/eclipse/rdf4j.git
clone Shazamcrest shazamcrest https://github.com/shazam/shazamcrest.git
clone Snomed_owl_toolkit snomed-owl-toolkit https://github.com/IHTSDO/snomed-owl-toolkit.git
clone Sparsebitset SparseBitSet https://github.com/brettwooldridge/SparseBitSet.git
clone Tascalate_concurrent tascalate-concurrent https://github.com/vsilaev/tascalate-concurrent.git
clone Aws_maven aws-maven https://github.com/spring-attic/aws-maven.git
clone Cli_parser cli-parser https://github.com/spullara/cli-parser.git
clone Confluence_http_authenticator confluence_http_authenticator https://github.com/chauth/confluence_http_authenticator.git
clone Deft deft https://github.com/rschildmeijer/deft.git
clone Doubleclick_core openrtb-doubleclick-core https://github.com/google/openrtb-doubleclick.git
clone Dropwizard_spring dropwizard-spring https://github.com/nhuray/dropwizard-spring.git
clone Hierarchical_clustering_java hierarchical-clustering-java https://github.com/lbehnke/hierarchical-clustering-java.git
clone Hive_funnel_udf hive-funnel-udf https://github.com/yahoo/hive-funnel-udf.git
clone Incubator_retired_pirk incubator-retired-pirk https://github.com/apache/incubator-retired-pirk.git
clone JacksonModuleJsonSchema jackson-module-jsonSchema https://github.com/FasterXML/jackson-module-jsonSchema.git
clone Jackson_annotations jackson-annotations https://github.com/FasterXML/jackson-annotations.git
clone Jackson_datatype_hibernate4 jackson-datatype-hibernate4 https://github.com/FasterXML/jackson-datatype-hibernate.git
clone Jcabi_aether jcabi-aether https://github.com/jcabi/jcabi-aether.git
clone Jcabi_w3c jcabi-w3c https://github.com/jcabi/jcabi-w3c.git
clone Jchronic jchronic https://github.com/samtingleff/jchronic.git
clone Jfreesvg jfreesvg https://github.com/jfree/jfreesvg.git
clone Jmimemagic jmimemagic https://github.com/arimus/jmimemagic.git
clone Jnagmp jnagmp https://github.com/square/jna-gmp.git
clone Kafka_graphite kafka-graphite https://github.com/damienclaveau/kafka-graphite.git
clone Netconf_java netconf-java https://github.com/Juniper/netconf-java.git
clone Rdf4j_query rdf4j-query https://github.com/eclipse/rdf4j.git
clone Rdf4j_rio_rdfxml rdf4j-rio-rdfxml https://github.com/eclipse/rdf4j.git
clone Rocketmq_mqtt_cs rocketmq-mqtt-cs https://github.com/apache/rocketmq-mqtt.git
clone Rocketmq_mqtt_ds rocketmq-mqtt-ds https://github.com/apache/rocketmq-mqtt.git
clone Semux_core semux-core https://github.com/semuxproject/semux-core.git
clone Simple_excel simple-excel https://github.com/tobyweston/simple-excel.git
clone Slack_java_webhook slack-java-webhook https://github.com/ashwanthkumar/slack-java-webhook.git
clone Spring_context_support spring-context-support https://github.com/alibaba/spring-context-support.git
clone Stash_jenkins_postreceive_webhook stash-jenkins-postreceive-webhook https://github.com/mohamicorp/stash-jenkins-postreceive-webhook.git
clone Subethasmtp subethasmtp https://github.com/davidmoten/subethasmtp.git
clone Suffixtree suffixtree https://github.com/abahgat/suffixtree.git
clone Template_benchmark template-benchmark https://github.com/mbosecke/template-benchmark.git
clone Tempus_fugit tempus-fugit https://github.com/tobyweston/tempus-fugit.git
clone Trident_ml trident-ml https://github.com/pmerienne/trident-ml.git
clone Weak_lock_free weak-lock-free https://github.com/raphw/weak-lock-free.git
