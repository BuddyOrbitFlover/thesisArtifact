#!/bin/bash
exec 9>/catena/censusb_s4.lock
flock -n 9 || { echo "stage4 already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
cd /catena/scripts/split_tests
mkdir -p running running_censusb_bak
mv running/* running_censusb_bak/ 2>/dev/null
echo "== split_tests $(date) — 171 bugs =="
python3 run.py ./tableGB -d /gb -f /catena/censusb_mh.txt -w /tmp/censusb -m /catena/scripts/construct_database/d4j_export/database.censusb.json 2>&1 | tail -8
cp running/res5.json /catena/censusb_res5.json
python3 -c "import json;r=json.load(open('/catena/censusb_res5.json'));print('STAGE4 DONE:',len(r),'bugs in censusb_res5.json (of 171)')"
touch /catena/censusb_s4.done
