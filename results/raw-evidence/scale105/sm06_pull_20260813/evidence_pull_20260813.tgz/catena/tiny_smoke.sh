#!/bin/bash
export PATH=/gb/framework/bin:$PATH
ok=0; fails=()
while read -r p b; do
  w=/tmp/smoke_${p}_${b}; rm -rf "$w"
  if defects4j checkout -p "$p" -v "${b}b" -w "$w" >/dev/null 2>&1; then ok=$((ok+1)); else fails+=("$p $b"); fi
  rm -rf "$w"
done < /catena/tiny_gh_smoke.txt
echo "SMOKE: OK=$ok FAIL=${#fails[@]} of $(wc -l < /catena/tiny_gh_smoke.txt)"
[ ${#fails[@]} -gt 0 ] && printf 'FAIL %s\n' "${fails[@]}"
