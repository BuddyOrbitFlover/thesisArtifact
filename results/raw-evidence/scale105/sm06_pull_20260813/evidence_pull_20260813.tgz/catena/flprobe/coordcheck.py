#!/usr/bin/env python3
# coordcheck.py: replay each bug's exported patch JSON on the pristine BUGGY
# file (git) and byte-compare against the FIXED commit in the same workdir git.
# Diagnosis only: reads everything, writes nothing outside stdout.
import json, subprocess, sys, difflib

BUGS = ["RTree_1","RTree_6","RTree_7","Wicket_core_1","Javapoet_2","Zip4j_1",
        "Tika_core_9","Tika_core_23","Dropwizard_spring_1","JacksonModuleJsonSchema_1"]

def git_show(wd, ref, path):
    r = subprocess.run(["git","-C",wd,"show",f"{ref}:{path}"],
                       capture_output=True, text=True)
    return r.stdout.splitlines(keepends=True) if r.returncode==0 else None

def find_commit(wd, marker):
    r = subprocess.run(["git","-C",wd,"log","--format=%H %s"],
                       capture_output=True, text=True)
    for line in r.stdout.splitlines():
        h, _, s = line.partition(" ")
        if marker in s:
            return h
    return None

for bug in BUGS:
    proj, bid = bug.rsplit("_",1)
    wd = f"/catena/scripts/gb_diag/working/data/{bug}"
    jp = f"/catena/scripts/parse_patches/patches/{proj}/{bid}.json"
    print(f"===== {bug}")
    try:
        pj = json.load(open(jp))
    except Exception as e:
        print("  no JSON:", e); continue
    hunks = [pj[k] for k in sorted((k for k in pj if k.isdigit()), key=int)]
    buggy_c = find_commit(wd, "BUGGY_VERSION")
    fixed_c = find_commit(wd, "FIXED_VERSION")
    if not (buggy_c and fixed_c):
        print("  missing git refs"); continue
    files = sorted(set(h["file_name"] for h in hunks))
    for fn in files:
        b = git_show(wd, buggy_c, fn); f = git_show(wd, fixed_c, fn)
        if b is None or f is None:
            print(f"  {fn}: MISSING in git ({'buggy' if b is None else 'fixed'})"); continue
        # replay edits (absolute coords, apply bottom-up so positions stay valid)
        edits = []
        for i,h in enumerate(hunks):
            if h["file_name"] != fn: continue
            t = h["patch_type"]
            if t == "insert":
                edits.append((h["next_line_no"], i, "insert", 0,
                              h.get("replaced_with") or ""))
            elif t == "delete":
                edits.append((h["from_line_no"], i, "delete",
                              h["to_line_no"]-h["from_line_no"]+1, ""))
            elif t == "replace":
                edits.append((h["from_line_no"], i, "replace",
                              h["to_line_no"]-h["from_line_no"]+1,
                              h.get("replaced_with") or ""))
        out = list(b)
        for pos, i, t, cnt, txt in sorted(edits, reverse=True):
            new = txt.splitlines(keepends=True)
            if t == "insert":
                out[pos-1:pos-1] = new
            elif t == "delete":
                del out[pos-1:pos-1+cnt]
            else:
                out[pos-1:pos-1+cnt] = new
        if out == f:
            print(f"  {fn}: replay == FIXED (coordinates correct)")
            continue
        # mismatch: locate ground truth via difflib buggy->fixed
        sm = difflib.SequenceMatcher(None, b, f, autojunk=False)
        ops = [o for o in sm.get_opcodes() if o[0] != "equal"]
        print(f"  {fn}: REPLAY MISMATCH. ground-truth edit blocks: {len(ops)}, JSON hunks here: {len(edits)}")
        for tag,i1,i2,j1,j2 in ops:
            frag = "".join(f[j1:min(j2,j1+1)]).strip()[:60]
            print(f"    truth: {tag} buggy[{i1+1}..{i2}] -> fixed[{j1+1}..{j2}] {frag!r}")
        for pos,i,t,cnt,txt in sorted(edits):
            frag = (txt.splitlines() or [""])[0].strip()[:60]
            print(f"    json hunk{i}: {t} at {pos} count {cnt} {frag!r}")
