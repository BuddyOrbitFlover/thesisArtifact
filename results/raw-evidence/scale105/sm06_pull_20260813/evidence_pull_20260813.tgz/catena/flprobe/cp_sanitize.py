#!/usr/bin/env python3
# Rewrite a GZoltar classpath so javassist can scan it under Java 8.
# argv: cp_file outdir. Prints sanitized cp on stdout, diagnostics on stderr.
import sys, os, re, zipfile

cp_file, outdir = sys.argv[1], sys.argv[2]
os.makedirs(outdir, exist_ok=True)
entries = [e for e in open(cp_file).read().strip().split(":") if e]

def bad(n):
    return (n == "module-info.class" or n.endswith("/module-info.class")
            or n.startswith("META-INF/versions/"))

def sanitize_jar(path, idx):
    try:
        zin = zipfile.ZipFile(path)
    except Exception as e:
        print("  keep (unreadable zip: %s): %s" % (e, path), file=sys.stderr)
        return path
    hits = [n for n in zin.namelist() if bad(n)]
    if not hits:
        zin.close()
        return path
    out = os.path.join(outdir, "%02d_%s" % (idx, os.path.basename(path)))
    with zipfile.ZipFile(out, "w") as zout:
        for item in zin.infolist():
            if bad(item.filename):
                continue
            zout.writestr(item, zin.read(item.filename))
    zin.close()
    print("  sanitized (%d entries removed): %s" % (len(hits), os.path.basename(path)), file=sys.stderr)
    return out

def is_junit(e):
    b = os.path.basename(e)
    return b == "junit.jar" or re.match(r"junit[-._]?\d.*\.jar$", b) is not None

def junit_ver(e):
    m = re.search(r"junit[-._]?(\d+(?:\.\d+)*)", os.path.basename(e))
    return tuple(int(x) for x in m.group(1).split(".")) if m else (0,)

junits = [e for e in entries if is_junit(e)]
rest = [e for e in entries if not is_junit(e)]
ordered = []
if junits:
    best = max(junits, key=junit_ver)
    for j in junits:
        if j != best:
            print("  dropped junit: %s" % j, file=sys.stderr)
    print("  junit kept first: %s" % best, file=sys.stderr)
    ordered.append(best)
ordered += rest
final = []
for i, e in enumerate(ordered):
    if e.endswith(".jar") and os.path.isfile(e):
        final.append(sanitize_jar(e, i))
    else:
        final.append(e)
print(":".join(final))
