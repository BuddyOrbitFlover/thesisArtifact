#!/bin/bash
# FL GZoltar diagnosis for the 8 probe-passed attrition bugs.
# Reuses the /catena/flprobe checkouts; writes rankings to FLDIAG (not /catena/FL).
# Deliberately NO global java pkill (diag round may be running); only the gzoltar jar.
export PATH=/root/binshim:/gb/framework/bin:/catena:$PATH
LOG=/catena/flprobe/fl_diag.log
mkdir -p /catena/flprobe/FLDIAG
for BUG in Cli_parser_1_1 Shiro_core_203_1 Spoon_16_1 Zip4j_35_1 Zip4j_39_1 Zip4j_44_1 Zip4j_46_1 Zip4j_47_1; do
  C=${BUG##*_}; REST=${BUG%_*}; B=${REST##*_}; P=${REST%_*}
  W=/catena/flprobe/$BUG
  echo "=== $BUG $(date)" >> $LOG
  LC=/gb/framework/projects/$P/loaded_classes/$B.src
  RT=/gb/framework/projects/$P/relevant_tests/$B
  TC=$(while read c; do printf "%s:%s\$*:" "$c" "$c"; done < "$LC"); TC=${TC%:}
  TESTC=$(paste -sd: "$RT")
  cd "$W" || { echo "$BUG NO WORKDIR" >> $LOG; continue; }
  defects4j export -p cp.test -o cp.txt 2>/dev/null
  timeout -k 30 5400 java -jar /catena/gzoltar-1.6.0.jar -diagnose \
    -Dproject_cp="$(cat cp.txt)" \
    -Dtargetclasses="$TC" \
    -Dtestclasses="$TESTC" \
    -Dgzoltar_data_dir=$W/gzoltar-data \
    -Dtest_case_timeout=120 \
    -Dshow_progress_bar=false > gzoltar.log 2>&1
  rc=$?
  if [ -f $W/gzoltar-data/spectra ]; then
    mkdir -p /catena/flprobe/FLDIAG/$BUG
    python3 /catena/gz2ranking.py $W/gzoltar-data/spectra /catena/flprobe/FLDIAG/$BUG/ochiai.ranking.txt
    FR=$(awk "{print \$NF}" $W/gzoltar-data/matrix | grep -c "^-$")
    echo "$BUG OK rc=$rc failing_tests=$FR ranking_lines=$(wc -l < /catena/flprobe/FLDIAG/$BUG/ochiai.ranking.txt)" >> $LOG
  else
    echo "$BUG GZOLTAR-FAIL rc=$rc tail: $(tail -n 3 gzoltar.log | tr "\n" " " | cut -c1-200)" >> $LOG
  fi
  pkill -9 -f "[g]zoltar-1.6.0.jar" 2>/dev/null
done
curl -s -d "FL diag: 8 gzoltar runs finished" https://ntfy.sh/klee-tbar-9x42qz > /dev/null
echo "=== ALL DONE $(date)" >> $LOG
