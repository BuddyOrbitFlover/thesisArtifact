org.apache.tika.detect.MagicDetectorTest::testDetectString$catena_0
org.apache.tika.detect.MagicDetectorTest::testDetectString$catena_1
org.apache.tika.detect.MagicDetectorTest::testDetectString$catena_3
org.apache.tika.detect.MagicDetectorTest::testDetectString$catena_2
