org.apache.tika.detect.MagicDetectorTest::testDetectString$catena_4
