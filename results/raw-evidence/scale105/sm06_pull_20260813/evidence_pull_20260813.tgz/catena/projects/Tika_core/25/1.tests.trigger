org.apache.tika.mime.MimeTypesReaderTest::testMultiThreaded
