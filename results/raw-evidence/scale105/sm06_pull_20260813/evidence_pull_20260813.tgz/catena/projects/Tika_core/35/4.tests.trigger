org.apache.tika.sax.xpath.XPathParserTest::testDescendantOrSelfNode$catena_0
org.apache.tika.sax.xpath.XPathParserTest::testDescendantOrSelfNode$catena_6
org.apache.tika.sax.xpath.XPathParserTest::testDescendantOrSelfNode$catena_1
org.apache.tika.sax.xpath.XPathParserTest::testDescendantOrSelfNode$catena_3
org.apache.tika.sax.xpath.XPathParserTest::testDescendantOrSelfNode$catena_7
org.apache.tika.sax.xpath.XPathParserTest::testDescendantOrSelfNode$catena_4
