org.apache.tika.detect.TextDetectorTest::testDetectEmpty
