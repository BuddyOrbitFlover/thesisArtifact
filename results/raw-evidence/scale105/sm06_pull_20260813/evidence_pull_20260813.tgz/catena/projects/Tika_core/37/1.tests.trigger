org.apache.tika.sax.LinkContentHandlerTest::testScriptTag
