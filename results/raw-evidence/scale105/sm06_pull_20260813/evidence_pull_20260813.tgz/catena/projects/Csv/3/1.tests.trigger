org.apache.commons.csv.CSVLexerTest::testEscapedMySqlNullValue
org.apache.commons.csv.CSVLexerTest::testEscapedCharacter
org.apache.commons.csv.CSVParserTest::testBackslashEscaping$catena_1
