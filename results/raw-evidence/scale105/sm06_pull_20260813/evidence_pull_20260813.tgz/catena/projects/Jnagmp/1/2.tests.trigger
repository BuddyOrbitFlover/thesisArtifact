com.squareup.jnagmp.GmpTest::testSmallExhaustiveInsecure
