org.eclipse.rdf4j.rio.rdfjson.RDFJSONWriterTest::testPerformanceNoHandling
org.eclipse.rdf4j.rio.rdfjson.RDFJSONWriterTest::testRDFStarConversion
org.eclipse.rdf4j.rio.rdfjson.RDFJSONHandlingTest::testRDFStarCompatibility
org.eclipse.rdf4j.rio.rdfjson.RDFJSONWriterTest::testPerformance
