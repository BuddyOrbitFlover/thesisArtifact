#!/bin/bash
exec 9>/catena/censusb_s1.lock
flock -n 9 || { echo "already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
cd /catena/scripts/construct_database
mkdir -p /tmp/censusb
rm -f exception_*
echo "== checkouts $(date) =="
python3 check_out_projects.py ./censusb171 /tmp/censusb
ls exception_* 2>/dev/null || echo "checkouts clean"
echo "== exports (sequential, resumable) $(date) =="
python3 export_metadata2.py ./censusb171 /tmp/censusb
echo "== convert $(date) =="
cp -n d4j_export/database.json d4j_export/database.json.precensusb.bak
python3 convert_metadata.py ./censusb171 /tmp/censusb /gb
mv d4j_export/database.json d4j_export/database.censusb.json
cp d4j_export/database.json.precensusb.bak d4j_export/database.json
echo "STAGE1 DONE: $(python3 -c "import json;print(len(json.load(open('d4j_export/database.censusb.json'))))")/171 $(date)"
touch /catena/censusb_s1.done
