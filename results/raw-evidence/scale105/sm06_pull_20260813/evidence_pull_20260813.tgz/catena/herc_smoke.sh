#!/bin/bash
# Hercules identity-check smoke: Chart_18_2 with short ranking (README quick test),
# target = reproduce the published correct patch (RepairResults/Hercules).
exec 9>/catena/herc_smoke.lock
flock -n 9 || { echo "already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:/catena:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
cd /catena/hercules
mkdir -p /catena/herc_projects
echo "=== HERC SMOKE start $(date) ==="
# README quick-test prep: truncated ranking (backup.txt keeps the full original)
cp -n location/105SampleBugsResult/Chart_18_2/ochiai.ranking.txt location/105SampleBugsResult/Chart_18_2/ochiai.full.bak
cp location/105SampleBugsResult/Chart_18_2/short.txt location/105SampleBugsResult/Chart_18_2/ochiai.ranking.txt
# sub-bug checkout (catena4j, the line their run.sh has commented out)
rm -rf /catena/herc_projects/Chart_18_2
catena4j checkout -p Chart -v 18b2 -w /catena/herc_projects/Chart_18_2 || { echo "SMOKE FAIL: checkout"; exit 1; }
( cd /catena/herc_projects/Chart_18_2 && defects4j compile ) || { echo "SMOKE FAIL: compile"; exit 1; }
echo "--- generation (Main_NFL) $(date) ---"
java -cp Hercules-1.0-SNAPSHOT-jar-with-dependencies.jar org.example.hercules.Main_NFL \
  /catena/herc_projects /catena ./location/105SampleBugsResult ./test.txt herc_smoke_gen.log
echo "--- generation rc=$? $(date) ---"
echo "--- patches produced ---"
find patches -maxdepth 3 2>/dev/null | head -20
echo "--- validation $(date) ---"
python3 hercules_valid_v2.py /catena/herc_projects
echo "--- validation rc=$? $(date) ---"
echo "=== results/Chart_18_2.txt ==="
cat results/Chart_18_2.txt 2>/dev/null
echo "=== HERC SMOKE DONE $(date) ==="
