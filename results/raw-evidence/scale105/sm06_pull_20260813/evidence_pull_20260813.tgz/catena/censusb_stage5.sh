#!/bin/bash
exec 9>/catena/censusb_s5.lock
flock -n 9 || { echo "stage5 already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
cd /catena/scripts/generate_bugs
cp -n 2toMore 2toMore.precensusb.bak
cp /catena/censusb_mh.txt 2toMore
cp /catena/censusb_res5.json ./censusb_res5.json
echo "=== CENSUS-B STAGE 5 start $(date) — $(wc -l < 2toMore) bugs, -n 8, paper caps ==="
python3 run.py -m ../construct_database/d4j_export/database.censusb.json -t ./censusb_res5.json -p ../parse_patches/patches -n 8
echo "=== run.py rc=$? $(date) ==="
echo "=== VERDICT ==="
python3 verdict.py
touch /catena/censusb_s5.done
curl -s -d "CENSUS-B stage5 (171 divisibility) DONE" ntfy.sh/klee-tbar-9x42qz >/dev/null 2>&1
