#!/bin/bash
# Hercules gb smoke: one growingBugs sub-bug (Jcabi_aether_1_1) end-to-end in gb-div.
# Tests: multi-underscore id parsing (rsplit), catena4j gb checkout, our /catena/FL as
# FLroot, generation + validation with the paper's UNMODIFIED code (run.sh not used).
exec 9>/catena/herc_gbsmoke.lock
flock -n 9 || { echo "already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:/catena:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
BUG=Jcabi_aether_1_1
CID=${BUG##*_}; rest=${BUG%_*}; BID=${rest##*_}; PROJ=${rest%_*}
echo "=== HERC GBSMOKE start $(date) === BUG=$BUG PROJ=$PROJ BID=$BID CID=$CID"
WORK=/catena/herc_gb_smoke
rm -rf $WORK; mkdir -p $WORK/projects
tar -C /catena/hercules -cf - --exclude=patches --exclude=results --exclude=tmp --exclude=C4J_results --exclude=location . | tar -C $WORK -xf - || { echo "GBSMOKE FAIL: copy"; exit 1; }
cd $WORK
echo "$BUG" > gb_one.txt
[ -f /catena/FL/$BUG/ochiai.ranking.txt ] || { echo "GBSMOKE FAIL: no FL ranking"; exit 1; }
catena4j checkout -p $PROJ -v ${BID}b${CID} -w $WORK/projects/$BUG || { echo "GBSMOKE FAIL: checkout"; exit 1; }
( cd $WORK/projects/$BUG && defects4j compile ) || { echo "GBSMOKE FAIL: compile"; exit 1; }
echo "--- generation $(date) ---"
timeout -k 30 18000 java -cp Hercules-1.0-SNAPSHOT-jar-with-dependencies.jar org.example.hercules.Main_NFL \
  $WORK/projects /catena /catena/FL gb_one.txt gbsmoke_gen.log
echo "--- generation rc=$? $(date) ---"
echo "--- patches produced ---"
find patches -maxdepth 3 2>/dev/null | head -20
echo "--- validation $(date) ---"
python3 hercules_valid_v2.py $WORK/projects
echo "--- validation rc=$? $(date) ---"
echo "=== results ==="
cat results/$BUG.txt 2>/dev/null
echo "=== time info ==="
cat patches/$BUG/time_info*.txt 2>/dev/null; echo; cat time_info.txt 2>/dev/null
echo "=== HERC GBSMOKE DONE $(date) ==="
