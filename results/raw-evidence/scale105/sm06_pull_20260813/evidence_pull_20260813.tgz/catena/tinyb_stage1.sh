#!/bin/bash
exec 9>/catena/tinyb_s1.lock
flock -n 9 || { echo "already running"; exit 1; }
export PATH=/root/binshim:/gb/framework/bin:$PATH
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF8 -XX:ActiveProcessorCount=5"
cd /catena/scripts/construct_database_tinyb
mkdir -p /tmp/tinyb
rm -f exception_*
echo "== checkouts $(date) =="
python3 check_out_projects.py ./tinyb74 /tmp/tinyb
ls exception_* 2>/dev/null || echo "checkouts clean"
echo "== exports (sequential, resumable) $(date) =="
python3 export_metadata2.py ./tinyb74 /tmp/tinyb
echo "== convert $(date) =="
cp -n d4j_export/database.json d4j_export/database.json.pretinyb.bak
python3 convert_metadata.py ./tinyb74 /tmp/tinyb /gb
mv d4j_export/database.json d4j_export/database.tinyb.json
cp d4j_export/database.json.pretinyb.bak d4j_export/database.json
echo "STAGE1 DONE: $(python3 -c "import json;print(len(json.load(open('d4j_export/database.tinyb.json'))))")/74 $(date)"
touch /catena/tinyb_s1.done
