#!/bin/bash
while :; do
  D=$(ls /catena/RESULTS_GB3/done 2>/dev/null | wc -l)
  F=$(ls /catena/RESULTS_GB3/fixed 2>/dev/null | wc -l)
  L=$(uptime | grep -oE "load average.*")
  R=$(wc -l < /catena/tbar3_reaper.log 2>/dev/null || echo 0)
  W=""
  for i in 0 1 2 3; do
    b=$(grep -oE "^--- [A-Za-z0-9_]+ start" /catena/rq2_tbar3_w$i.log 2>/dev/null | tail -1 | awk "{print \$2}")
    W="$W w$i:${b:-idle}"
  done
  if [ -f /catena/rq2tbar3.done ]; then
    curl -s -H "Title: TBar census" -H "Tags: tada" -d "FINISHED: $D/67 done, $F with patches" ntfy.sh/klee-tbar-9x42qz >/dev/null 2>&1
    break
  fi
  curl -s -H "Title: TBar census" -H "Tags: hourglass" -d "done $D/67 | patches $F |$W
$L | reaper $R" ntfy.sh/klee-tbar-9x42qz >/dev/null 2>&1
  sleep 1800
done
