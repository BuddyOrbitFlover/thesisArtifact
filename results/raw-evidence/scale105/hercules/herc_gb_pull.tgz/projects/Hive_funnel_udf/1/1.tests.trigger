com.yahoo.hive.udf.funnel.FunnelTest::testPartial1
