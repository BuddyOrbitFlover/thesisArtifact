org.jsoup.parser.XmlTreeBuilderTest::handlesDodgyXmlDecl
