org.jsoup.parser.HtmlParserTest::handlesKnownEmptyStyle
org.jsoup.parser.HtmlParserTest::handlesKnownEmptyNoFrames
