com.google.googlejavaformat.java.MainTest::newline$catena_0
com.google.googlejavaformat.java.MainTest::newline$catena_1
