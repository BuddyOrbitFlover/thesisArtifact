com.google.googlejavaformat.java.MainTest::newline$catena_0
