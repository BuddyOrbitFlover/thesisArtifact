org.locationtech.proj4j.proj.ProjectionEqualityTest::utmEquality$catena_0
