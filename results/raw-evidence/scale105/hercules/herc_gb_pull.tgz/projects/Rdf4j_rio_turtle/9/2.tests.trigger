org.eclipse.rdf4j.rio.turtle.TurtlePrettyWriterTest::testDontAbbreviateNumbers$catena_0
org.eclipse.rdf4j.rio.turtle.TurtlePrettyWriterTest::testDontAbbreviateNumbers$catena_2
org.eclipse.rdf4j.rio.turtle.TurtlePrettyWriterTest::testDontAbbreviateNumbers$catena_1
