com.jcabi.aether.AetherTest::recoversAfterFailure$catena_1
com.jcabi.aether.AetherTest::recoversAfterFailure$catena_0
com.jcabi.aether.AetherTest::throwsWhenArtifactNotFound
com.jcabi.aether.RootArtifactTest::gracefullyResolvesBrokenRootArtifact
com.jcabi.aether.AetherTest::recoversAfterFailure$catena_2
com.jcabi.aether.ClasspathTest::hasToStringWithBrokenDependency
