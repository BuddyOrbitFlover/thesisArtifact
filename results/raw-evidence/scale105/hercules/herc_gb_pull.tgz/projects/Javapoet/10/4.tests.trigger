com.squareup.javawriter.JavaWriterTest::testStringLiteral$catena_5
