com.google.gson.functional.TypeVariableTest::testSingle
