com.google.gson.stream.JsonWriterTest::testBoxedBooleans
