io.github.gitbucket.markedj.MarkedTest::testEmptyTableCell
