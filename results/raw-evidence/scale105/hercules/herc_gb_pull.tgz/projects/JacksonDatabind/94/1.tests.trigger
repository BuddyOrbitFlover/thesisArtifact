com.fasterxml.jackson.databind.interop.IllegalTypesCheckTest::testC3P0Types
