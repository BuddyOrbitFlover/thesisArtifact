com.fasterxml.jackson.databind.node.TestObjectNode::testIssue941
