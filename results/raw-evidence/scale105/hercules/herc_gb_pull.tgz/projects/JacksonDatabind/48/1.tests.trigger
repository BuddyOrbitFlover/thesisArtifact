com.fasterxml.jackson.databind.ser.TestFeatures::testVisibilityFeatures
