com.fasterxml.jackson.databind.deser.jdk.JDKScalarsTest::testVoidDeser
