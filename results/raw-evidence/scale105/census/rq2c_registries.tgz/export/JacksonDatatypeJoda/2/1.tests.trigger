com.fasterxml.jackson.datatype.joda.DateTimeTest::testAsTextNoMilliseconds
