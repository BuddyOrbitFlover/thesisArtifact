com.github.davidmoten.rtree.FunctionsTest::testConstructorIsPrivate
