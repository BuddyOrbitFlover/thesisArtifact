org.apache.commons.validator.routines.LongValidatorTest::testInvalidStrict
org.apache.commons.validator.routines.LongValidatorTest::testInvalidNotStrict
