org.apache.commons.validator.routines.IntegerValidatorTest::testValidNotStrict
org.apache.commons.validator.routines.ByteValidatorTest::testValidNotStrict
