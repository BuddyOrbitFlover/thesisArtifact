com.iciql.test.PrimitivesTest::testPrimitiveColumnSelection$catena_1
com.iciql.test.PrimitivesTest::testPrimitiveColumnSelection$catena_0
