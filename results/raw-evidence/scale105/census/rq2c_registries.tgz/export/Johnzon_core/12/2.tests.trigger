org.apache.johnzon.core.JsonReaderImplTest::badTypeObject
