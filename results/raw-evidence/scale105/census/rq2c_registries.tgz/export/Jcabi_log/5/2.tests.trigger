com.jcabi.log.NoArgTest::handlePercent
