com.jcabi.log.NoArgTest::handleNewLine
