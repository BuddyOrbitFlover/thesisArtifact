com.jcabi.log.LoggerTest::findsArgsByPositions
