org.shredzone.commons.suncalc.SunTimesTest::testAlert$catena_5
org.shredzone.commons.suncalc.SunTimesTest::testAlert$catena_4
org.shredzone.commons.suncalc.SunTimesTest::testWellington
org.shredzone.commons.suncalc.SunTimesTest::testAlert$catena_3
org.shredzone.commons.suncalc.SunTimesTest::testAlert$catena_0
org.shredzone.commons.suncalc.SunTimesTest::testAlert$catena_2
