org.shredzone.commons.suncalc.MoonTimesTest::testCologne$catena_1
org.shredzone.commons.suncalc.MoonTimesTest::testPuertoWilliams$catena_1
org.shredzone.commons.suncalc.MoonTimesTest::testAlert$catena_13
org.shredzone.commons.suncalc.MoonTimesTest::testWellington$catena_2
org.shredzone.commons.suncalc.MoonTimesTest::testSingapore$catena_1
org.shredzone.commons.suncalc.MoonTimesTest::testWellington$catena_0
