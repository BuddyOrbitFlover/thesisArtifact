net.lingala.zip4j.ExtractZipFileIT::testExtractJarFile
