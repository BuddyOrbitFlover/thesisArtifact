com.sampullara.cli.ArgsTest::testDerivedCommand$catena_0
com.sampullara.cli.ArgsTest::testDerivedCommand$catena_1
