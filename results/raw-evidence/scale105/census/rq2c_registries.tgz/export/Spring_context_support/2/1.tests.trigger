com.alibaba.spring.util.BeanUtilsTest::testGetBeanNamesOnXmlBean
