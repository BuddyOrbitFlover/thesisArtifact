com.fasterxml.jackson.databind.type.RecursiveType1658Test::testRecursive1658
