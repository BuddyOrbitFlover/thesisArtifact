org.apache.commons.lang3.time.DateUtilsFragmentTest::testDaysOfYearWithDate
org.apache.commons.lang3.time.DateUtilsFragmentTest::testDaysOfYearWithCalendar
